<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreUserRequest;
use App\Http\Requests\Admin\UpdateUserRequest;
use App\Models\Operator;
use App\Models\User;
use App\Role;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class UserController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', User::class);

        $authUser = auth()->user();

        $q = trim((string)$request->query('q', ''));
        $roleFilter = trim((string)$request->query('role', ''));
        $perPage = (int)$request->query('per_page', 15);
        $perPage = ($perPage > 0 && $perPage <= 100) ? $perPage : 15;

        // ===== Super Admin =====
        if ($authUser->isSuperAdmin()) {

            $companyOwnersQuery = User::query()
                ->whereHas('roleModel', fn ($r) => $r->where('name', 'company_owner'))
                ->with([
                    'ownedOperators' => function ($op) {
                        $op->latest()->withCount(['users as employees_count']);
                    },
                ]);

            if ($q !== '') {
                $companyOwnersQuery->where(function ($x) use ($q) {
                    $x->where('name', 'like', "%{$q}%")
                        ->orWhere('username', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%")
                        ->orWhereHas('ownedOperators', function ($op) use ($q) {
                            $op->where('name', 'like', "%{$q}%")
                                ->orWhere('unit_number', 'like', "%{$q}%");
                        });
                });
            }

            $companyOwners = $companyOwnersQuery
                ->latest()
                ->paginate($perPage, ['*'], 'owners_page')
                ->withQueryString();

            // سلطة الطاقة + النظام
            $otherUsersQuery = User::query()
                ->whereHas('roleModel', fn ($r) => $r->whereIn('name', ['admin','super_admin']))
                ->with('roleModel');

            if ($roleFilter !== '') {
                $otherUsersQuery->whereHas('roleModel', fn ($r) => $r->where('name', $roleFilter));
            }

            if ($q !== '') {
                $otherUsersQuery->where(function ($x) use ($q) {
                    $x->where('name', 'like', "%{$q}%")
                        ->orWhere('username', 'like', "%{$q}%")
                        ->orWhere('email', 'like', "%{$q}%");
                });
            }

            $otherUsers = $otherUsersQuery
                ->latest()
                ->paginate($perPage, ['*'], 'others_page')
                ->withQueryString();

            // ✅ Ajax: رجّع partial list فقط
            if ($request->ajax()) {
                return view('admin.users.partials.list', compact('companyOwners', 'otherUsers', 'q', 'roleFilter'));
            }

            return view('admin.users.index', compact('companyOwners', 'otherUsers', 'q', 'roleFilter'));
        }

        // ===== Company Owner =====
        if ($authUser->isCompanyOwner()) {
            $operator = $authUser->ownedOperators()->first();

            $employees = collect();

            if ($operator) {
                $employeesQuery = User::query()
                    ->whereHas('operators', fn ($x) => $x->where('operators.id', $operator->id))
                    ->whereHas('roleModel', fn ($r) => $r->whereIn('name', ['employee','technician']))
                    ->with('roleModel');

                if ($roleFilter !== '') {
                    $employeesQuery->whereHas('roleModel', fn ($r) => $r->where('name', $roleFilter));
                }

                if ($q !== '') {
                    $employeesQuery->where(function ($x) use ($q) {
                        $x->where('name', 'like', "%{$q}%")
                            ->orWhere('username', 'like', "%{$q}%")
                            ->orWhere('email', 'like', "%{$q}%");
                    });
                }

                $employees = $employeesQuery->latest()->paginate($perPage)->withQueryString();
            }

            if ($request->ajax()) {
                return view('admin.users.partials.list', compact('employees', 'operator', 'q', 'roleFilter'));
            }

            return view('admin.users.index', compact('employees', 'operator', 'q', 'roleFilter'));
        }

        // default
        if ($request->ajax()) {
            return view('admin.users.partials.list', ['employees' => collect(), 'q' => $q, 'roleFilter' => $roleFilter]);
        }
        return view('admin.users.index', ['employees' => collect(), 'q' => $q, 'roleFilter' => $roleFilter]);
    }

    public function create(Request $request): View
    {
        $this->authorize('create', User::class);

        $authUser = auth()->user();
        $defaultRole = trim((string)$request->query('role', ''));

        // roles
        $roles = collect(Role::cases());
        if ($authUser->isCompanyOwner()) {
            $roles = $roles->filter(fn ($r) => in_array($r, [Role::Employee, Role::Technician], true));
        }

        // operators
        $operatorLocked = null;
        $operators = collect();

        if ($authUser->isCompanyOwner()) {
            $operatorLocked = $authUser->ownedOperators()->first();
        }

        // ✅ Ajax Modal
        if ($request->ajax() || $request->boolean('modal')) {
            return view('admin.users.partials.modal-form', [
                'mode' => 'create',
                'user' => null,
                'roles' => $roles,
                'defaultRole' => $defaultRole,
                'operatorLocked' => $operatorLocked,
                'operators' => $operators,
            ]);
        }

        return view('admin.users.create', compact('roles', 'operators', 'operatorLocked', 'defaultRole'));
    }

    public function edit(Request $request, User $user): View
    {
        $this->authorize('update', $user);

        $authUser = auth()->user();

        $roles = collect(Role::cases());
        if ($authUser->isCompanyOwner()) {
            $roles = $roles->filter(fn ($r) => in_array($r, [Role::Employee, Role::Technician], true));
        }

        $operatorLocked = null;
        $operators = collect();
        if ($authUser->isCompanyOwner()) {
            $operatorLocked = $authUser->ownedOperators()->first();
        }

        $userOperators = $user->operators->pluck('id')->toArray();
        $selectedOperator = $user->operators->first();

        if ($request->ajax() || $request->boolean('modal')) {
            return view('admin.users.partials.modal-form', [
                'mode' => 'edit',
                'user' => $user,
                'roles' => $roles,
                'defaultRole' => '',
                'operatorLocked' => $operatorLocked,
                'operators' => $operators,
                'userOperators' => $userOperators,
                'selectedOperator' => $selectedOperator,
            ]);
        }

        return view('admin.users.edit', compact('user', 'roles', 'operators', 'operatorLocked', 'userOperators'));
    }

    public function store(StoreUserRequest $request)
    {
        $authUser = auth()->user();
        $role = Role::from($request->validated('role'));

        if ($authUser->isCompanyOwner() && !in_array($role, [Role::Employee, Role::Technician], true)) {
            return $this->jsonOrRedirect($request, false, 'يمكنك إنشاء موظفين وفنيين فقط.');
        }

        $user = User::create([
            'name' => $request->validated('name'),
            'username' => $request->validated('username'),
            'email' => $request->validated('email'),
            'password' => Hash::make($request->validated('password')),
            'role' => $role,
        ]);

        // ربط الموظف/الفني بمشغل واحد فقط
        if ($user->isEmployee() || $user->isTechnician()) {
            if ($authUser->isCompanyOwner()) {
                $operator = $authUser->ownedOperators()->first();
                if (!$operator) {
                    $user->delete();
                    return $this->jsonOrRedirect($request, false, 'لا يوجد مشغل مرتبط بحسابك. أكمل ملف المشغل أولاً.');
                }
                $user->operators()->sync([$operator->id]);
            } else {
                $operatorId = (int)$request->input('operator_id');
                if (!$operatorId) {
                    $user->delete();
                    return $this->jsonOrRedirect($request, false, 'اختر المشغل لربط الموظف/الفني.');
                }
                $user->operators()->sync([$operatorId]);
            }
        }

        return $this->jsonOrRedirect($request, true, 'تم إنشاء المستخدم بنجاح.');
    }

    public function update(UpdateUserRequest $request, User $user)
    {
        $authUser = auth()->user();

        $data = [
            'name' => $request->validated('name'),
            'username' => $request->validated('username'),
            'email' => $request->validated('email'),
            'role' => Role::from($request->validated('role')),
        ];

        if ($request->filled('password')) {
            $data['password'] = Hash::make($request->validated('password'));
        }

        $user->update($data);

        if ($user->isEmployee() || $user->isTechnician()) {
            if ($authUser->isCompanyOwner()) {
                $operator = $authUser->ownedOperators()->first();
                if (!$operator) {
                    return $this->jsonOrRedirect($request, false, 'لا يوجد مشغل مرتبط بحسابك.');
                }
                $user->operators()->sync([$operator->id]);
            } else {
                $operatorIds = Arr::wrap($request->input('operator_id', []));
                $operatorIds = array_values(array_filter($operatorIds));
                if (empty($operatorIds)) {
                    return $this->jsonOrRedirect($request, false, 'اختر المشغل لربط الموظف/الفني.');
                }
                $user->operators()->sync([(int)$operatorIds[0]]);
            }
        } else {
            $user->operators()->detach();
        }

        return $this->jsonOrRedirect($request, true, 'تم تحديث المستخدم بنجاح.');
    }

    public function destroy(Request $request, User $user)
    {
        $this->authorize('delete', $user);

        if ($user->id === auth()->id()) {
            return $this->jsonOrRedirect($request, false, 'لا يمكنك حذف حسابك الخاص.');
        }

        $user->delete();

        return $this->jsonOrRedirect($request, true, 'تم حذف المستخدم بنجاح.');
    }

    /**
     * Select2 operators (server-side)
     */
    public function ajaxOperators(Request $request)
    {
        $authUser = auth()->user();
        if (!$authUser || !$authUser->isSuperAdmin()) {
            abort(403);
        }

        $term = trim((string)$request->query('q', ''));
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 10;

        $query = Operator::query()->orderBy('name');

        if ($term !== '') {
            $query->where(function ($x) use ($term) {
                $x->where('name', 'like', "%{$term}%")
                    ->orWhere('unit_number', 'like', "%{$term}%");
            });
        }

        $p = $query->paginate($perPage, ['id', 'name', 'unit_number'], 'page', $page);

        $results = $p->getCollection()->map(function ($op) {
            $suffix = $op->unit_number ? " - {$op->unit_number}" : '';
            return ['id' => $op->id, 'text' => $op->name . $suffix];
        })->values();

        return response()->json([
            'results' => $results,
            'pagination' => ['more' => $p->hasMorePages()],
        ]);
    }

    private function jsonOrRedirect(Request $request, bool $ok, string $message)
    {
        if ($request->wantsJson() || $request->ajax()) {
            return response()->json([
                'ok' => $ok,
                'message' => $message,
            ], $ok ? Response::HTTP_OK : Response::HTTP_UNPROCESSABLE_ENTITY);
        }

        return $ok
            ? redirect()->route('admin.users.index')->with('success', $message)
            : redirect()->back()->withInput()->with('error', $message);
    }
}
