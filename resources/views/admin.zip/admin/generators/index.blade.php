@extends('layouts.admin')

@section('title', 'إدارة المولدات')

@php
    $breadcrumbTitle = 'إدارة المولدات';
@endphp

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-lightning-charge me-2"></i>
                        إدارة المولدات
                    </h5>
                    @can('create', App\Models\Generator::class)
                        <a href="{{ route('admin.generators.create') }}" class="btn btn-sm">
                            <i class="bi bi-plus-circle me-1"></i>
                                إضافة مولد جديد
                            </a>
                        @endcan
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-nowrap">رقم المولد</th>
                                    <th class="text-nowrap">اسم المولد</th>
                                    <th class="text-nowrap d-none d-lg-table-cell">المشغل</th>
                                    <th class="text-nowrap d-none d-md-table-cell">القدرة (KVA)</th>
                                    <th class="text-nowrap">الحالة</th>
                                    <th class="text-nowrap d-none d-xl-table-cell">تاريخ الإنشاء</th>
                                    <th class="text-nowrap">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($generators as $generator)
                                    <tr>
                                        <td class="text-nowrap">
                                            <span class="badge bg-secondary">{{ $generator->generator_number }}</span>
                                        </td>
                                        <td class="text-nowrap">
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-2">{{ substr($generator->name, 0, 1) }}</div>
                                                <div>
                                                    <span class="fw-semibold d-block">{{ $generator->name }}</span>
                                                    <small class="text-muted d-lg-none">
                                                        @if($generator->operator)
                                                            {{ $generator->operator->name }}
                                                        @endif
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="d-none d-lg-table-cell">
                                            @if($generator->operator)
                                                <span class="badge bg-primary">{{ $generator->operator->name }}</span>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="d-none d-md-table-cell">
                                            @if($generator->capacity_kva)
                                                <span class="fw-semibold">{{ number_format($generator->capacity_kva, 2) }} KVA</span>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="text-nowrap">
                                            @if($generator->status === 'active')
                                                <span class="badge bg-success">فعال</span>
                                            @else
                                                <span class="badge bg-danger">غير فعال</span>
                                            @endif
                                        </td>
                                        <td class="d-none d-xl-table-cell">
                                            <small class="text-muted">{{ $generator->created_at->format('Y-m-d') }}</small>
                                        </td>
                                        <td class="text-nowrap">
                                            <div class="d-flex gap-2">
                                                @can('view', $generator)
                                                    <a href="{{ route('admin.generators.show', $generator) }}" class="btn btn-sm btn-outline-info">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                @endcan
                                                @can('update', $generator)
                                                    <a href="{{ route('admin.generators.edit', $generator) }}" class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                @endcan
                                                @can('delete', $generator)
                                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal{{ $generator->id }}">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>

                                    @can('delete', $generator)
                                        <div class="modal fade" id="deleteModal{{ $generator->id }}" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">تأكيد الحذف</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>هل أنت متأكد من حذف المولد <strong>{{ $generator->name }}</strong>؟</p>
                                                        <p class="text-danger"><small>هذا الإجراء لا يمكن التراجع عنه</small></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                        <form action="{{ route('admin.generators.destroy', $generator) }}" method="POST" class="d-inline">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit" class="btn btn-danger">حذف</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endcan
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                            لا توجد مولدات
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if($generators->hasPages())
                    <div class="card-footer">
                        {{ $generators->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
