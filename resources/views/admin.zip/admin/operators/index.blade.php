@extends('layouts.admin')

@section('title', 'إدارة المشغلين')

@php
    $breadcrumbTitle = 'إدارة المشغلين';
@endphp

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-building me-2"></i>
                        إدارة المشغلين
                    </h5>
                    @can('create', App\Models\Operator::class)
                        <a href="{{ route('admin.operators.create') }}" class="btn btn-sm">
                            <i class="bi bi-plus-circle me-1"></i>
                            إضافة مشغل جديد
                        </a>
                    @endcan
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="text-nowrap">اسم المشغل</th>
                                    <th class="text-nowrap d-none d-md-table-cell">البريد الإلكتروني</th>
                                    <th class="text-nowrap d-none d-lg-table-cell">الهاتف</th>
                                    <th class="text-nowrap d-none d-lg-table-cell">صاحب المشغل</th>
                                    <th class="text-nowrap">عدد المولدات</th>
                                    <th class="text-nowrap d-none d-xl-table-cell">تاريخ الإنشاء</th>
                                    <th class="text-nowrap">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($operators as $operator)
                                    <tr>
                                        <td class="text-nowrap">
                                            <div class="d-flex align-items-center">
                                                <div class="avatar-circle me-2">{{ substr($operator->name, 0, 1) }}</div>
                                                <div>
                                                    <span class="fw-semibold d-block">{{ $operator->name }}</span>
                                                    <small class="text-muted d-md-none">{{ $operator->email ?? '-' }}</small>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="d-none d-md-table-cell">{{ $operator->email ?? '-' }}</td>
                                        <td class="d-none d-lg-table-cell">{{ $operator->phone ?? '-' }}</td>
                                        <td class="d-none d-lg-table-cell">
                                            @if($operator->owner)
                                                <span class="badge bg-primary">{{ $operator->owner->name }}</span>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                        <td class="text-nowrap">
                                            <span class="badge bg-info">{{ $operator->generators->count() }} مولد</span>
                                        </td>
                                        <td class="d-none d-xl-table-cell">
                                            <small class="text-muted">{{ $operator->created_at->format('Y-m-d') }}</small>
                                        </td>
                                        <td class="text-nowrap">
                                            <div class="d-flex gap-2">
                                                @can('view', $operator)
                                                    <a href="{{ route('admin.operators.show', $operator) }}" class="btn btn-sm btn-outline-info">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                @endcan
                                                @can('update', $operator)
                                                    <a href="{{ route('admin.operators.edit', $operator) }}" class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                @endcan
                                                @can('delete', $operator)
                                                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal{{ $operator->id }}">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                @endcan
                                            </div>
                                        </td>
                                    </tr>

                                    @can('delete', $operator)
                                        <div class="modal fade" id="deleteModal{{ $operator->id }}" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">تأكيد الحذف</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p>هل أنت متأكد من حذف المشغل <strong>{{ $operator->name }}</strong>؟</p>
                                                        <p class="text-danger"><small>سيتم حذف حساب المستخدم المرتبط أيضاً. هذا الإجراء لا يمكن التراجع عنه</small></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                        <form action="{{ route('admin.operators.destroy', $operator) }}" method="POST" class="d-inline">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit" class="btn btn-danger">حذف</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endcan
                                @empty
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                            لا توجد مشغلين
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
                @if($operators->hasPages())
                    <div class="card-footer">
                        {{ $operators->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection
