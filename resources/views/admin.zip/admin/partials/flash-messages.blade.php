{{-- Flash Messages Component - Now handled by AdminNotifications (Bootstrap Toasts) in admin.blade.php --}}
{{-- All messages are displayed as Bootstrap Toast notifications, no Blade alerts --}}

