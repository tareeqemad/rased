<footer class="footer mt-auto py-3 bg-white text-center border-top">
    <div class="container">
        <span class="d-inline-flex align-items-center gap-1">
            <i class="bi bi-lightning-charge-fill text-warning"></i>
            <span>
                © {{ date('Y') }}
                <a href="#" class="text-primary fw-semibold text-decoration-underline">
                    راصد
                </a>
                — جميع الحقوق محفوظة.
            </span>
        </span>
    </div>
</footer>

