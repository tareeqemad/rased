<aside class="app-sidebar sticky" id="sidebar">
    <!-- Start::main-sidebar-header -->
    <div class="main-sidebar-header">
        <a href="{{ route('admin.dashboard') }}" class="header-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_white.webp') }}" alt="logo" class="desktop-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-logo.png') }}" alt="logo" class="toggle-logo">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_dark.webp') }}" alt="logo" class="desktop-dark">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-dark.png') }}" alt="logo" class="toggle-dark">
            <img src="{{ asset('assets/admin/images/brand-logos/logo_white.webp') }}" alt="logo" class="desktop-white">
            <img src="{{ asset('assets/admin/images/brand-logos/toggle-white.png') }}" alt="logo" class="toggle-white">
        </a>
    </div>
    <!-- End::main-sidebar-header -->

    <!-- Start::main-sidebar -->
    <div class="main-sidebar" id="sidebar-scroll">
        <nav class="main-menu-container nav nav-pills flex-column sub-open">

            <div class="slide-left" id="slide-left">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path>
                </svg>
            </div>

            @php
                $isActive = fn($routes) => request()->routeIs($routes) ? 'active' : '';
                $isOpen   = fn($routes) => request()->routeIs($routes) ? 'open'   : '';
                $show     = fn($routes) => request()->routeIs($routes) ? 'display:block' : '';
            @endphp

            <ul class="main-menu">

                <!-- 1) Dashboard -->
                <li class="slide {{ $isActive('admin.dashboard') }}">
                    <a href="{{ route('admin.dashboard') }}" class="side-menu__item">
                        <i class="bi bi-house-door side-menu__icon"></i>
                        <span class="side-menu__label">لوحة التحكم</span>
                    </a>
                </li>

                <!-- 2) System Management (Super Admin Only) -->
                @can('viewAny', App\Models\Role::class)
                    <li class="slide__category mt-3">
                        <span class="side-menu__label text-muted text-xs opacity-70">إدارة النظام</span>
                    </li>

                    <!-- Permissions Tree -->
                    <li class="slide {{ $isActive('admin.permissions.*') }}">
                        <a href="{{ route('admin.permissions.index') }}" class="side-menu__item">
                            <i class="bi bi-diagram-3 side-menu__icon"></i>
                            <span class="side-menu__label">شجرة الصلاحيات</span>
                        </a>
                    </li>

                    <!-- Roles -->
                    <li class="slide has-sub {{ $isOpen('admin.roles.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.roles.*') }}">
                            <i class="bi bi-shield-check side-menu__icon"></i>
                            <span class="side-menu__label">الأدوار</span>
                            <i class="bi bi-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.roles.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.roles.index') }}" class="side-menu__item {{ $isActive('admin.roles.index') }}">
                                    قائمة الأدوار
                                </a>
                            </li>
                            @can('create', App\Models\Role::class)
                                <li class="slide">
                                    <a href="{{ route('admin.roles.create') }}" class="side-menu__item {{ $isActive('admin.roles.create') }}">
                                        إضافة دور جديد
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>

                    <!-- Constants -->
                    <li class="slide {{ $isActive('admin.constants.*') }}">
                        <a href="{{ route('admin.constants.index') }}" class="side-menu__item">
                            <i class="bi bi-database side-menu__icon"></i>
                            <span class="side-menu__label">إدارة الثوابت</span>
                        </a>
                    </li>

                    <!-- Users -->
                    <li class="slide has-sub {{ $isOpen('admin.users.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.users.*') }}">
                            <i class="bi bi-people side-menu__icon"></i>
                            <span class="side-menu__label">المستخدمون</span>
                            <i class="bi bi-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.users.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.users.index') }}" class="side-menu__item {{ $isActive('admin.users.index') }}">
                                    قائمة المستخدمين
                                </a>
                            </li>
                            @can('create', App\Models\User::class)
                                <li class="slide">
                                    <a href="{{ route('admin.users.create') }}" class="side-menu__item {{ $isActive('admin.users.create') }}">
                                        إضافة مستخدم جديد
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                <!-- 3) Operations Management -->
                <li class="slide__category mt-3">
                    <span class="side-menu__label text-muted text-xs opacity-70">إدارة العمليات</span>
                </li>

                <!-- Operators -->
                @can('viewAny', App\Models\Operator::class)
                    <li class="slide has-sub {{ $isOpen('admin.operators.*') }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.operators.*') }}">
                            <i class="bi bi-building side-menu__icon"></i>
                            <span class="side-menu__label">المشغلون</span>
                            <i class="bi bi-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.operators.*') }}">
                            <li class="slide">
                                <a href="{{ route('admin.operators.index') }}" class="side-menu__item {{ $isActive('admin.operators.index') }}">
                                    قائمة المشغلين
                                </a>
                            </li>
                            @can('create', App\Models\Operator::class)
                                <li class="slide">
                                    <a href="{{ route('admin.operators.create') }}" class="side-menu__item {{ $isActive('admin.operators.create') }}">
                                        إضافة مشغل جديد
                                    </a>
                                </li>
                            @endcan
                        </ul>
                    </li>
                @endcan

                <!-- Generators with Submenu -->
                @can('viewAny', App\Models\Generator::class)
                    <li class="slide has-sub {{ $isOpen('admin.generators.*') || $isOpen('admin.operation-logs.*') || $isOpen('admin.fuel-efficiencies.*') || $isOpen('admin.maintenance-records.*') || $isOpen('admin.compliance-safeties.*') ? 'open' : '' }}">
                        <a href="javascript:void(0);" class="side-menu__item {{ $isActive('admin.generators.*') || $isActive('admin.operation-logs.*') || $isActive('admin.fuel-efficiencies.*') || $isActive('admin.maintenance-records.*') || $isActive('admin.compliance-safeties.*') ? 'active' : '' }}">
                            <i class="bi bi-lightning-charge side-menu__icon"></i>
                            <span class="side-menu__label">المولدات</span>
                            <i class="bi bi-chevron-left side-menu__angle"></i>
                        </a>
                        <ul class="slide-menu child1" style="{{ $show('admin.generators.*') || $show('admin.operation-logs.*') || $show('admin.fuel-efficiencies.*') || $show('admin.maintenance-records.*') || $show('admin.compliance-safeties.*') ? 'display:block' : '' }}">
                            <li class="slide">
                                <a href="{{ route('admin.generators.index') }}" class="side-menu__item {{ $isActive('admin.generators.index') }}">
                                    <span class="side-menu__label">المولدات</span>
                                </a>
                            </li>
                            <li class="slide">
                                <a href="{{ route('admin.operation-logs.index') }}" class="side-menu__item {{ $isActive('admin.operation-logs.index') }}">
                                    <span class="side-menu__label">سجلات التشغيل</span>
                                </a>
                            </li>
                            <li class="slide">
                                <a href="{{ route('admin.fuel-efficiencies.index') }}" class="side-menu__item {{ $isActive('admin.fuel-efficiencies.index') }}">
                                    <span class="side-menu__label">كفاءة الوقود</span>
                                </a>
                            </li>
                            <li class="slide">
                                <a href="{{ route('admin.maintenance-records.index') }}" class="side-menu__item {{ $isActive('admin.maintenance-records.index') }}">
                                    <span class="side-menu__label">سجلات الصيانة</span>
                                </a>
                            </li>
                            <li class="slide">
                                <a href="{{ route('admin.compliance-safeties.index') }}" class="side-menu__item {{ $isActive('admin.compliance-safeties.index') }}">
                                    <span class="side-menu__label">الامتثال والسلامة</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                @endcan

            </ul>

            <div class="slide-right" id="slide-right">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                    <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                </svg>
            </div>

        </nav>
    </div>
</aside>
