@extends('layouts.admin')

@section('title', 'إدارة المستخدمين')

@php
    $breadcrumbTitle = 'إدارة المستخدمين';
@endphp

@section('content')
    <div class="row">
        @if(auth()->user()->isSuperAdmin())
            <!-- المشغلين -->
            <div class="col-12 mb-4">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0 fw-bold">
                            <i class="bi bi-building me-2"></i>
                            المشغلين
                </h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>الاسم</th>
                                        <th>اسم المستخدم</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>اسم المشغل</th>
                                        <th>عدد الموظفين</th>
                                        <th>تاريخ الإنشاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($companyOwners ?? [] as $owner)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-circle me-2">{{ substr($owner->name, 0, 1) }}</div>
                                                    <span class="fw-semibold">{{ $owner->name }}</span>
                                                </div>
                                            </td>
                                            <td>{{ $owner->username }}</td>
                                            <td>{{ $owner->email }}</td>
                                            <td>
                                                @if($owner->ownedOperators->first())
                                                    <span class="badge bg-primary">{{ $owner->ownedOperators->first()->name }}</span>
                                                @else
                                                    <span class="text-muted">-</span>
                                                @endif
                                            </td>
                                            <td>
                                                @if($owner->ownedOperators->first())
                                                    <a href="{{ route('admin.operators.employees', $owner->ownedOperators->first()) }}" class="btn btn-sm btn-outline-info">
                                                        <i class="bi bi-people me-1"></i>
                                                        {{ $owner->employees_count ?? 0 }} موظف
                                                    </a>
                                                @else
                                                    <span class="text-muted">0</span>
                                                @endif
                                            </td>
                                            <td>
                                                <small class="text-muted">{{ $owner->created_at->format('Y-m-d') }}</small>
                                            </td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    @can('view', $owner)
                                                        <a href="{{ route('admin.users.show', $owner) }}" class="btn btn-sm btn-outline-info">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                    @endcan
                                                    @can('update', $owner)
                                                        <a href="{{ route('admin.users.edit', $owner) }}" class="btn btn-sm btn-outline-primary">
                                                            <i class="bi bi-pencil"></i>
                    </a>
                @endcan
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="7" class="text-center py-5 text-muted">
                                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                                لا يوجد مشغلين
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- مستخدمي سلطة الطاقة والأدوار الأخرى -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-shield-check me-2"></i>
                            مستخدمي سلطة الطاقة والأدوار الأخرى
                        </h5>
                    </div>
                    <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>الاسم</th>
                                <th>اسم المستخدم</th>
                                <th>البريد الإلكتروني</th>
                                        <th>الدور</th>
                                <th>تاريخ الإنشاء</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                                    @forelse($otherUsers ?? [] as $otherUser)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                                    <div class="avatar-circle me-2">{{ substr($otherUser->name, 0, 1) }}</div>
                                                    <span class="fw-semibold">{{ $otherUser->name }}</span>
                                        </div>
                                    </td>
                                            <td>{{ $otherUser->username }}</td>
                                            <td>{{ $otherUser->email }}</td>
                                            <td>
                                                @if($otherUser->roleModel)
                                                    <span class="badge bg-info">{{ $otherUser->roleModel->label }}</span>
                                        @else
                                                    <span class="badge bg-secondary">-</span>
                                        @endif
                                    </td>
                                    <td>
                                                <small class="text-muted">{{ $otherUser->created_at->format('Y-m-d') }}</small>
                                            </td>
                                            <td>
                                                <div class="d-flex gap-2">
                                                    @can('view', $otherUser)
                                                        <a href="{{ route('admin.users.show', $otherUser) }}" class="btn btn-sm btn-outline-info">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                    @endcan
                                                    @can('update', $otherUser)
                                                        <a href="{{ route('admin.users.edit', $otherUser) }}" class="btn btn-sm btn-outline-primary">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                    @endcan
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="6" class="text-center py-5 text-muted">
                                                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                                لا يوجد مستخدمين
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        @elseif(auth()->user()->isCompanyOwner())
            <!-- المشغل يرى موظفيه -->
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0 fw-bold">
                            <i class="bi bi-people-fill me-2"></i>
                            موظفي المشغل
                            @if(isset($operator))
                                - {{ $operator->name }}
                            @endif
                        </h5>
                        <div class="d-flex gap-2">
                            @can('create', App\Models\User::class)
                                <a href="{{ route('admin.users.create') }}" class="btn btn-sm">
                                    <i class="bi bi-plus-circle me-1"></i>
                                    إضافة موظف جديد
                                </a>
                            @endcan
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>الاسم</th>
                                        <th>اسم المستخدم</th>
                                        <th>البريد الإلكتروني</th>
                                        <th>الدور</th>
                                        <th>تاريخ الإنشاء</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($employees ?? [] as $employee)
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="avatar-circle me-2">{{ substr($employee->name, 0, 1) }}</div>
                                                    <span class="fw-semibold">{{ $employee->name }}</span>
                                                </div>
                                            </td>
                                            <td>{{ $employee->username }}</td>
                                            <td>{{ $employee->email }}</td>
                                            <td>
                                                @if($employee->roleModel)
                                                    <span class="badge bg-success">{{ $employee->roleModel->label }}</span>
                                        @else
                                                    <span class="badge bg-secondary">-</span>
                                        @endif
                                    </td>
                                    <td>
                                                <small class="text-muted">{{ $employee->created_at->format('Y-m-d') }}</small>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                                    @can('view', $employee)
                                                        <a href="{{ route('admin.users.show', $employee) }}" class="btn btn-sm btn-outline-info">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            @endcan
                                                    @can('update', $employee)
                                                        <a href="{{ route('admin.users.edit', $employee) }}" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            @endcan
                                                    @can('delete', $employee)
                                                        @if($employee->id !== auth()->id())
                                                            <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#deleteModal{{ $employee->id }}">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                @endif
                                            @endcan
                                        </div>
                                    </td>
                                </tr>

                                        @can('delete', $employee)
                                            @if($employee->id !== auth()->id())
                                                <div class="modal fade" id="deleteModal{{ $employee->id }}" tabindex="-1">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">تأكيد الحذف</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                                <p>هل أنت متأكد من حذف المستخدم <strong>{{ $employee->name }}</strong>؟</p>
                                                        <p class="text-danger"><small>هذا الإجراء لا يمكن التراجع عنه</small></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                                <form action="{{ route('admin.users.destroy', $employee) }}" method="POST" class="d-inline">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit" class="btn btn-danger">حذف</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    @endif
                                @endcan
                            @empty
                                <tr>
                                            <td colspan="6" class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                                لا يوجد موظفين
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
                    @if(isset($employees) && $employees->hasPages())
                        <div class="card-footer">
                            {{ $employees->links() }}
                </div>
            @endif
        </div>
            </div>
        @endif
    </div>
@endsection
