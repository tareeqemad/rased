@extends('layouts.admin')

@section('title', 'موظفي المشغل')

@php
    $breadcrumbTitle = 'موظفي المشغل';
    $breadcrumbParent = 'إدارة المستخدمين';
    $breadcrumbParentUrl = route('admin.users.index');
@endphp

@section('content')
    <div class="container-fluid">
        <div class="card border-0 shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="mb-0 fw-bold">
                        <i class="bi bi-people-fill me-2"></i>
                        موظفي المشغل: {{ $operator->name }}
                    </h5>
                    <small class="text-muted">عدد الموظفين: {{ $employees->total() }}</small>
                </div>
                <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-2"></i>
                    رجوع
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>الاسم</th>
                                <th>اسم المستخدم</th>
                                <th>البريد الإلكتروني</th>
                                <th>الدور</th>
                                <th>تاريخ الإنشاء</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($employees as $employee)
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-circle me-2">{{ substr($employee->name, 0, 1) }}</div>
                                            <span class="fw-semibold">{{ $employee->name }}</span>
                                        </div>
                                    </td>
                                    <td>{{ $employee->username }}</td>
                                    <td>{{ $employee->email }}</td>
                                    <td>
                                        @if($employee->roleModel)
                                            <span class="badge bg-success">{{ $employee->roleModel->label }}</span>
                                        @else
                                            <span class="badge bg-secondary">-</span>
                                        @endif
                                    </td>
                                    <td>
                                        <small class="text-muted">{{ $employee->created_at->format('Y-m-d') }}</small>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            @can('view', $employee)
                                                <a href="{{ route('admin.users.show', $employee) }}" class="btn btn-sm btn-outline-info">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                            @endcan
                                            @can('update', $employee)
                                                <a href="{{ route('admin.users.edit', $employee) }}" class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            @endcan
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center py-5 text-muted">
                                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                                        لا يوجد موظفين لهذا المشغل
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
            @if($employees->hasPages())
                <div class="card-footer bg-white border-top">
                    {{ $employees->links() }}
                </div>
            @endif
        </div>
    </div>
@endsection

