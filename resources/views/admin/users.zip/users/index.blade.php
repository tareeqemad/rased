@extends('layouts.admin')

@section('title', 'إدارة المستخدمين')

@php
    $authUser = auth()->user();
    $q = $q ?? '';
    $roleFilter = $roleFilter ?? '';
@endphp

@push('styles')
    <link rel="stylesheet" href="{{ asset('assets/admin/css/users.css') }}">
@endpush

@section('content')
<div class="users-page"
     data-index-url="{{ route('admin.users.index') }}"
     data-operators-url="{{ route('admin.ajax.operators') }}">

    {{-- Page Header --}}
    <div class="users-page-header">
        <div>
            <h1 class="users-title">إدارة المستخدمين</h1>
            <div class="users-subtitle">
                @if($authUser->isSuperAdmin())
                    السوبر أدمن: إدارة المشغلين + سلطة الطاقة + إنشاء/تعديل المستخدمين.
                @elseif($authUser->isCompanyOwner())
                    المشغل: إدارة موظفين/فنيين تابعين لك فقط (عزل كامل).
                @else
                    لا يوجد صلاحية لعرض هذه الصفحة.
                @endif
            </div>
        </div>

        <div class="d-flex gap-2">
            @can('create', \App\Models\User::class)
                @if($authUser->isSuperAdmin())
                    <div class="dropdown">
                        <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                            <i class="bi bi-plus-lg me-1"></i> إضافة
                        </button>

                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item js-user-create"
                                   href="{{ route('admin.users.create', ['role' => \App\Role::CompanyOwner->value]) }}">
                                    <i class="bi bi-building me-2"></i> مشغل جديد
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item js-user-create"
                                   href="{{ route('admin.users.create', ['role' => \App\Role::Admin->value]) }}">
                                    <i class="bi bi-lightning-charge me-2"></i> مستخدم سلطة الطاقة
                                </a>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <a class="dropdown-item js-user-create"
                                   href="{{ route('admin.users.create', ['role' => \App\Role::Employee->value]) }}">
                                    <i class="bi bi-person-badge me-2"></i> موظف
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item js-user-create"
                                   href="{{ route('admin.users.create', ['role' => \App\Role::Technician->value]) }}">
                                    <i class="bi bi-tools me-2"></i> فني
                                </a>
                            </li>
                        </ul>
                    </div>
                @elseif($authUser->isCompanyOwner())
                    <a class="btn btn-primary js-user-create" href="{{ route('admin.users.create') }}">
                        <i class="bi bi-person-plus me-1"></i> إضافة موظف/فني
                    </a>
                @endif
            @endcan
        </div>
    </div>

    {{-- Filters Card --}}
    <div class="card ui-card">
        <div class="card-body">
            <form id="usersFiltersForm" class="users-filters" method="GET" action="{{ route('admin.users.index') }}">
                <div class="row g-2 align-items-end">

                    <div class="col-lg-6">
                        <label class="form-label">بحث</label>
                        <div class="ui-input-icon">
                            <i class="bi bi-search icon"></i>
                            <input type="text" name="q" value="{{ $q }}" class="form-control"
                                   placeholder="اسم / اسم مستخدم / بريد / اسم مشغل...">
                        </div>
                    </div>

                    <div class="col-lg-3">
                        <label class="form-label">الدور</label>

                        @if($authUser->isSuperAdmin())
                            <select name="role" class="form-select">
                                <option value="">الكل</option>
                                <option value="admin" {{ $roleFilter === 'admin' ? 'selected' : '' }}>سلطة الطاقة</option>
                                <option value="super_admin" {{ $roleFilter === 'super_admin' ? 'selected' : '' }}>مدير النظام</option>
                            </select>
                        @elseif($authUser->isCompanyOwner())
                            <select name="role" class="form-select">
                                <option value="">الكل</option>
                                <option value="employee" {{ $roleFilter === 'employee' ? 'selected' : '' }}>موظف</option>
                                <option value="technician" {{ $roleFilter === 'technician' ? 'selected' : '' }}>فني</option>
                            </select>
                        @else
                            <select class="form-select" disabled>
                                <option>—</option>
                            </select>
                        @endif
                    </div>

                    <div class="col-lg-3">
                        <label class="form-label">عدد النتائج</label>
                        <select name="per_page" class="form-select">
                            @php $pp = request('per_page', 15); @endphp
                            <option value="15" {{ (string)$pp === '15' ? 'selected' : '' }}>15</option>
                            <option value="25" {{ (string)$pp === '25' ? 'selected' : '' }}>25</option>
                            <option value="50" {{ (string)$pp === '50' ? 'selected' : '' }}>50</option>
                        </select>
                    </div>

                    <div class="col-12 d-flex gap-2 justify-content-end mt-2">
                        <button class="btn btn-primary" type="submit">
                            بحث
                        </button>

                        {{-- Reset without reload --}}
                        <button class="btn btn-light-subtle" type="button" id="usersResetBtn">
                            إلغاء
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>

    {{-- Results Container (AJAX updates this div) --}}
    <div id="usersListContainer">
        @if($authUser->isSuperAdmin())
            @include('admin.users.partials.list', [
                'companyOwners' => $companyOwners ?? collect(),
                'otherUsers' => $otherUsers ?? collect(),
                'q' => $q,
                'roleFilter' => $roleFilter,
            ])
        @elseif($authUser->isCompanyOwner())
            @include('admin.users.partials.list', [
                'employees' => $employees ?? collect(),
                'operator' => $operator ?? null,
                'q' => $q,
                'roleFilter' => $roleFilter,
            ])
        @else
            <div class="card ui-card">
                <div class="card-body text-center text-muted py-5">
                    لا يوجد صلاحية للوصول.
                </div>
            </div>
        @endif
    </div>

    {{-- Create/Edit Modal --}}
    <div class="modal fade" id="userFormModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userFormModalTitle">إضافة/تعديل</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body" id="userFormModalBody">
                    <div class="text-center py-5">
                        <div class="spinner-border" role="status"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Delete Confirm Modal --}}
    <div class="modal fade" id="deleteUserModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأكيد الحذف</h5>
                    <button class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    هل أنت متأكد من حذف المستخدم: <strong id="deleteUserName">-</strong>؟
                    <div class="text-danger mt-2"><small>هذا الإجراء لا يمكن التراجع عنه.</small></div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light-subtle" data-bs-dismiss="modal">إلغاء</button>
                    <button class="btn btn-danger" id="confirmDeleteBtn">حذف</button>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection

@push('scripts')
<script>
    // قيم الأدوار جاهزة للـ JS لو احتجتها (بدل hardcode)
    window.UsersAjaxConfig = {
        employee: @json(\App\Role::Employee->value),
        technician: @json(\App\Role::Technician->value),
        companyOwner: @json(\App\Role::CompanyOwner->value),
        admin: @json(\App\Role::Admin->value),
        superAdmin: @json(\App\Role::SuperAdmin->value),
    };

    // زر الإلغاء: صفّر الفلاتر بدون Reload + عمل submit (AJAX)
    document.addEventListener('DOMContentLoaded', function () {
        const btn = document.getElementById('usersResetBtn');
        const form = document.getElementById('usersFiltersForm');
        if (!btn || !form) return;

        btn.addEventListener('click', function () {
            const q = form.querySelector('[name="q"]');
            const role = form.querySelector('[name="role"]');
            const perPage = form.querySelector('[name="per_page"]');
            if (q) q.value = '';
            if (role) role.value = '';
            if (perPage) perPage.value = '15';

            form.dispatchEvent(new Event('submit', { cancelable: true }));
        });
    });
</script>

<script src="{{ asset('assets/admin/js/users-ajax.js') }}"></script>
@endpush
